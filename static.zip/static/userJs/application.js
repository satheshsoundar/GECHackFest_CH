/**
 * 
 */
var uri='http://localhost:4334/LearingPathBuilder/api/';
var gecHackfest=angular.module('GecHackFest',['ngRoute']);
gecHackfest.config(function($routeProvider) {
	  $routeProvider
	  .when("/", {
	    templateUrl : "home.html"
	  })
	  .when("/videos", {
	    templateUrl : "video.html"
	  })
	  .when("/speakers", {
	    templateUrl : "speakers.html"
	  })
	  .when("/schedule", {
	    templateUrl : "schedule.html"
	  });
	});
gecHackfest.factory('loginService', function() {
	  var loginService={};
	  loginService.username=null;;
	 
	  return loginService;
	});

gecHackfest.controller('navCtrl',function($scope,$http,loginService){
	$scope.user_name=null;
	$scope.verfy={};
	$scope.verfy.user_name=null;
	$scope.verfy.pass=null;
	$scope.verfyUser=function(verify){
	/*$http.post(uri+'/login',$scope.verfy).then(
			function(success){
				console.log('success:'+success.data);
				loginService.loginService.username=$scope.verify.user_name;
				$scope.user_name=$scope.verify.user_name;
				
			},
			
			function(error){
				console.log(error.data);
				
			}
			);*/
		
		$scope.user_name=$scope.verfy.user_name;
	};
	
});